package com.masai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MasaiFirApplicationTests {

	@Test
	void contextLoads() {
	}

}
