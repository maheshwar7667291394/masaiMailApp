package com.masai.exception;

public class FirException extends Exception {
	
	public FirException() {
		// TODO Auto-generated constructor stub
	}
	
	public FirException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
