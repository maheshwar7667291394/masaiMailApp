package com.masaiemail.exception;

public class EmailException extends Exception {
	
	
	public EmailException() {
		// TODO Auto-generated constructor stub
	}
	
	
	public EmailException(String msg) {
		super(msg);
	}

}
